Restock Radar - files for GitHub Pages
Upload these 4 files to the root of your repo: index.html, data.json, routes.json, base.jpg
Then: repo Settings > Pages > Source: "Deploy from a branch" > Branch: main, folder: / (root) > Save.
Your site appears at https://YOUR-USERNAME.github.io/REPO-NAME/ in about a minute.
To update the data by hand, replace data.json with a newer one.
